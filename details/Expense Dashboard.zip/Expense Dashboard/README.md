
  # Expense Dashboard

  This is a code bundle for Expense Dashboard. The original project is available at https://www.figma.com/design/LIJLttYx37uMBSgUR6XTJM/Expense-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  