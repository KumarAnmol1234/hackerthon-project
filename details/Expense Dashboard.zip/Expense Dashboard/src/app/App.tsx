import { useState } from "react";
import { ExpenseForm, Expense } from "@/app/components/ExpenseForm";
import { ExpenseList } from "@/app/components/ExpenseList";
import { ExpensePieChart } from "@/app/components/ExpensePieChart";
import { ExpenseBarChart } from "@/app/components/ExpenseBarChart";
import { StatCard } from "@/app/components/StatCard";
import { Navbar } from "@/app/components/Navbar";
import { ProfileDialog } from "@/app/components/ProfileDialog";
import { DollarSign, TrendingUp, Calendar, Wallet } from "lucide-react";

export default function App() {
  const [user, setUser] = useState<{ name: string; email: string; avatar?: string } | null>({
    name: "Guest User",
    email: "guest@example.com",
  });
  const [showSignInDialog, setShowSignInDialog] = useState(false);
  const [showProfileDialog, setShowProfileDialog] = useState(false);
  
  const [expenses, setExpenses] = useState<Expense[]>([
    {
      id: "1",
      category: "Food & Dining",
      amount: 45.99,
      description: "Grocery shopping",
      date: "2026-01-15",
    },
    {
      id: "2",
      category: "Transportation",
      amount: 60.0,
      description: "Gas",
      date: "2026-01-14",
    },
    {
      id: "3",
      category: "Entertainment",
      amount: 25.5,
      description: "Movie tickets",
      date: "2026-01-13",
    },
    {
      id: "4",
      category: "Bills & Utilities",
      amount: 120.0,
      description: "Electricity bill",
      date: "2026-01-10",
    },
    {
      id: "5",
      category: "Food & Dining",
      amount: 32.75,
      description: "Restaurant",
      date: "2026-01-12",
    },
  ]);

  const handleAddExpense = (expense: Omit<Expense, "id">) => {
    const newExpense: Expense = {
      ...expense,
      id: Date.now().toString(),
    };
    setExpenses([...expenses, newExpense]);
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(expenses.filter((expense) => expense.id !== id));
  };

  const handleSignOut = () => {
    // Just a placeholder - doesn't actually log out in this version
    alert("Sign out functionality");
  };

  const handleViewProfile = () => {
    setShowProfileDialog(true);
  };

  // Calculate statistics
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const averageExpense =
    expenses.length > 0 ? totalExpenses / expenses.length : 0;
  const monthExpenses = expenses.filter((expense) => {
    const expenseDate = new Date(expense.date);
    const now = new Date();
    return (
      expenseDate.getMonth() === now.getMonth() &&
      expenseDate.getFullYear() === now.getFullYear()
    );
  });
  const monthTotal = monthExpenses.reduce((sum, expense) => sum + expense.amount, 0);

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        user={user}
        onSignIn={() => setShowSignInDialog(true)}
        onSignOut={handleSignOut}
        onViewProfile={handleViewProfile}
      />
      
      <ProfileDialog
        open={showProfileDialog}
        onOpenChange={setShowProfileDialog}
        user={user}
        totalExpenses={totalExpenses}
        transactionCount={expenses.length}
      />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Expense Dashboard</h1>
          <p className="text-muted-foreground">
            Track and visualize your financial expenses
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            title="Total Expenses"
            value={`$${totalExpenses.toFixed(2)}`}
            icon={DollarSign}
            description="All time"
          />
          <StatCard
            title="This Month"
            value={`$${monthTotal.toFixed(2)}`}
            icon={Calendar}
            description={`${monthExpenses.length} transaction${monthExpenses.length !== 1 ? "s" : ""}`}
          />
          <StatCard
            title="Average Expense"
            value={`$${averageExpense.toFixed(2)}`}
            icon={TrendingUp}
            description="Per transaction"
          />
          <StatCard
            title="Total Transactions"
            value={expenses.length.toString()}
            icon={Wallet}
            description="All entries"
          />
        </div>

        {/* Expense Form */}
        <div className="mb-8">
          <ExpenseForm onAddExpense={handleAddExpense} />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <ExpensePieChart expenses={expenses} />
          <ExpenseBarChart expenses={expenses} />
        </div>

        {/* Expense List */}
        <ExpenseList expenses={expenses} onDeleteExpense={handleDeleteExpense} />
      </div>
    </div>
  );
}